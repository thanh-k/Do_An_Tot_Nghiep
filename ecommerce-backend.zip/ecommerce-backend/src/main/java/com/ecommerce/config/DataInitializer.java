package com.ecommerce.config;

import com.ecommerce.entity.AccessPermission;
import com.ecommerce.entity.AccessRole;
import com.ecommerce.entity.PhonePrefix;
import com.ecommerce.entity.User;
import com.ecommerce.entity.UserAddress;
import com.ecommerce.modules.news.entity.NewsPost;
import com.ecommerce.modules.news.entity.NewsPostStatus;
import com.ecommerce.modules.news.entity.NewsTopic;
import com.ecommerce.modules.news.repository.NewsPostRepository;
import com.ecommerce.modules.news.repository.NewsTopicRepository;
import com.ecommerce.modules.phoneprefix.repository.PhonePrefixRepository;
import com.ecommerce.modules.role.entity.RoleName;
import com.ecommerce.modules.role.repository.AccessPermissionRepository;
import com.ecommerce.modules.role.repository.AccessRoleRepository;
import com.ecommerce.modules.user.repository.UserAddressRepository;
import com.ecommerce.modules.user.repository.UserRepository;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.RequiredArgsConstructor;
import org.springframework.boot.CommandLineRunner;
import org.springframework.core.io.ClassPathResource;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

import java.io.InputStream;
import java.time.LocalDateTime;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

@Component
@RequiredArgsConstructor
public class DataInitializer implements CommandLineRunner {

    private final PhonePrefixRepository phonePrefixRepository;
    private final UserRepository userRepository;
    private final UserAddressRepository userAddressRepository;
    private final PasswordEncoder passwordEncoder;
    private final ObjectMapper objectMapper;
    private final JdbcTemplate jdbcTemplate;
    private final AccessPermissionRepository accessPermissionRepository;
    private final AccessRoleRepository accessRoleRepository;
    private final NewsTopicRepository newsTopicRepository;
    private final NewsPostRepository newsPostRepository;

    @Override
    public void run(String... args) throws Exception {
        relaxLegacyUsersSchema();
        seedPhonePrefixes();
        seedAccessControl();
        seedAdminAccount();
        seedNewsContent();
        syncUsersToDynamicRoles();
    }

    private void relaxLegacyUsersSchema() {
        try {
            Integer phoneColumn = jdbcTemplate.queryForObject(
                    "SELECT COUNT(*) FROM information_schema.columns " +
                            "WHERE table_schema = DATABASE() AND table_name = 'users' AND column_name = 'phone'",
                    Integer.class
            );
            if (phoneColumn != null && phoneColumn > 0) {
                jdbcTemplate.execute("ALTER TABLE users MODIFY COLUMN phone VARCHAR(10) NULL");
            }

            Integer passwordColumn = jdbcTemplate.queryForObject(
                    "SELECT COUNT(*) FROM information_schema.columns " +
                            "WHERE table_schema = DATABASE() AND table_name = 'users' AND column_name = 'password_hash'",
                    Integer.class
            );
            if (passwordColumn != null && passwordColumn > 0) {
                jdbcTemplate.execute("ALTER TABLE users MODIFY COLUMN password_hash TEXT NULL");
            }
        } catch (Exception ignored) {
        }
    }

    private void seedPhonePrefixes() throws Exception {
        if (phonePrefixRepository.count() > 0) return;

        InputStream inputStream = new ClassPathResource("data/phone-prefixes.json").getInputStream();
        List<Map<String, String>> items = objectMapper.readValue(inputStream, new TypeReference<>() {});

        List<PhonePrefix> prefixes = items.stream()
                .map(item -> PhonePrefix.builder()
                        .prefix(item.get("prefix"))
                        .providerName(item.get("providerName"))
                        .active(true)
                        .build())
                .toList();

        phonePrefixRepository.saveAll(prefixes);
    }

    private void seedAccessControl() {
        List<AccessPermission> permissions = List.of(

                permission("ROLE_MANAGE", "Quản lý danh sách vai trò", "ACCESS"),
                permission("ROLE_ASSIGN", "Gán vai trò cho người dùng", "ACCESS"),

                permission("USER_VIEW", "Xem người dùng", "USER"),
                permission("USER_CREATE", "Tạo người dùng", "USER"),
                permission("USER_UPDATE", "Cập nhật người dùng", "USER"),
                permission("USER_DELETE", "Ngưng hoạt động / hủy tài khoản người dùng", "USER"),
                permission("USER_LOCK", "Khóa / mở khóa người dùng", "USER"),
                permission("CUSTOMER_VIEW", "Xem khách hàng", "CUSTOMER"),
                permission("STAFF_VIEW", "Xem nhân sự", "STAFF"),

                permission("PHONE_PREFIX_VIEW", "Xem đầu số điện thoại", "PHONE"),
                permission("PHONE_PREFIX_MANAGE", "Quản lý đầu số điện thoại", "PHONE"),

                permission("NEWS_TOPIC_VIEW", "Xem chủ đề tin tức", "NEWS_TOPIC"),
                permission("NEWS_TOPIC_CREATE", "Thêm chủ đề tin tức", "NEWS_TOPIC"),
                permission("NEWS_TOPIC_UPDATE", "Sửa chủ đề tin tức", "NEWS_TOPIC"),
                permission("NEWS_TOPIC_DELETE", "Xóa chủ đề tin tức", "NEWS_TOPIC"),

                permission("NEWS_POST_VIEW", "Xem bài viết tin tức", "NEWS_POST"),
                permission("NEWS_POST_CREATE", "Thêm bài viết tin tức", "NEWS_POST"),
                permission("NEWS_POST_UPDATE", "Sửa bài viết tin tức", "NEWS_POST"),
                permission("NEWS_POST_DELETE", "Xóa bài viết tin tức", "NEWS_POST"),
                permission("NEWS_POST_PUBLISH", "Xuất bản bài viết tin tức", "NEWS_POST"),

                permission("CONTACT_VIEW", "Xem liên hệ", "CONTACT"),
                permission("CONTACT_REPLY", "Phản hồi liên hệ", "CONTACT"),
                permission("CONTACT_UPDATE", "Cập nhật trạng thái liên hệ", "CONTACT"),

                permission("DASHBOARD_VIEW", "Xem bảng điều khiển tổng quan", "DASHBOARD"),
                permission("ANALYTICS_VIEW", "Xem thống kê", "ANALYTICS"),
                permission("ANALYTICS_EXPORT", "Xuất báo cáo thống kê", "ANALYTICS"),

                permission("RECOMMENDATION_VIEW", "Xem gợi ý sản phẩm", "RECOMMENDATION"),
                permission("RECOMMENDATION_MANAGE", "Quản lý gợi ý sản phẩm", "RECOMMENDATION"),
                permission("BEHAVIOR_VIEW", "Xem hành vi người dùng", "BEHAVIOR"),

                permission("ANNOUNCEMENT_VIEW", "Xem thông báo chạy đầu trang", "ANNOUNCEMENT"),
                permission("ANNOUNCEMENT_MANAGE", "Quản lý thông báo chạy đầu trang", "ANNOUNCEMENT"),

                permission("WALLET_VIEW", "Xem ví thành viên", "WALLET"),
                permission("WALLET_TOPUP", "Nạp tiền vào ví", "WALLET"),
                permission("WALLET_DEDUCT", "Trừ tiền ví", "WALLET"),
                permission("WALLET_TRANSACTION_VIEW", "Xem lịch sử giao dịch ví", "WALLET"),

                permission("MEMBERSHIP_VIEW", "Xem hạng thành viên", "MEMBERSHIP"),
                permission("MEMBERSHIP_UPDATE", "Cập nhật hạng thành viên", "MEMBERSHIP"),
                permission("MEMBERSHIP_MANAGE", "Quản lý hạng thành viên", "MEMBERSHIP"),

                permission("PAYMENT_VIEW", "Xem thông tin thanh toán", "PAYMENT"),
                permission("PAYMENT_USE", "Sử dụng thanh toán", "PAYMENT"),
                permission("PAYMENT_MANAGE", "Quản lý thanh toán", "PAYMENT"),
                permission("PAYMENT_VERIFY", "Xác thực giao dịch thanh toán", "PAYMENT"),

                permission("VOUCHER_VIEW", "Xem voucher", "VOUCHER"),
                permission("VOUCHER_CREATE", "Thêm voucher", "VOUCHER"),
                permission("VOUCHER_UPDATE", "Sửa voucher", "VOUCHER"),
                permission("VOUCHER_DELETE", "Xóa voucher", "VOUCHER"),
                permission("VOUCHER_VALIDATE", "Kiểm tra voucher", "VOUCHER"),
                permission("VOUCHER_APPLY", "Áp dụng voucher", "VOUCHER"),

                permission("PRODUCT_VIEW", "Xem sản phẩm", "PRODUCT"),
                permission("PRODUCT_CREATE", "Thêm sản phẩm", "PRODUCT"),
                permission("PRODUCT_UPDATE", "Sửa sản phẩm", "PRODUCT"),
                permission("PRODUCT_DELETE", "Xóa sản phẩm", "PRODUCT"),
                permission("PRODUCT_MANAGE", "Quản lý sản phẩm", "PRODUCT"),

                permission("BRAND_VIEW", "Xem thương hiệu", "BRAND"),
                permission("BRAND_CREATE", "Thêm thương hiệu", "BRAND"),
                permission("BRAND_UPDATE", "Sửa thương hiệu", "BRAND"),
                permission("BRAND_DELETE", "Xóa thương hiệu", "BRAND"),

                permission("LIVESTREAM_VIEW", "Xem quản lý livestream", "LIVESTREAM"),
                permission("LIVESTREAM_MANAGE", "Quản lý livestream", "LIVESTREAM"),

                permission("PRODUCT_VIDEO_VIEW", "Xem video mô tả sản phẩm", "PRODUCT_VIDEO"),
                permission("PRODUCT_VIDEO_MANAGE", "Quản lý video mô tả sản phẩm", "PRODUCT_VIDEO"),

                permission("CATEGORY_VIEW", "Xem danh mục", "CATEGORY"),
                permission("CATEGORY_CREATE", "Thêm danh mục", "CATEGORY"),
                permission("CATEGORY_UPDATE", "Sửa danh mục", "CATEGORY"),
                permission("CATEGORY_DELETE", "Xóa danh mục", "CATEGORY"),

                permission("INVENTORY_VIEW", "Xem tồn kho", "INVENTORY"),
                permission("INVENTORY_UPDATE", "Cập nhật tồn kho", "INVENTORY"),

                permission("IMAGE_UPLOAD", "Tải ảnh sản phẩm", "IMAGE"),
                permission("IMAGE_DELETE", "Xóa ảnh sản phẩm", "IMAGE"),

                permission("VISION_SEARCH", "Tìm kiếm bằng hình ảnh", "VISION"),
                permission("VISION_MANAGE", "Quản lý tìm kiếm hình ảnh", "VISION"),

                permission("COMPARE_PRODUCT_USE", "So sánh sản phẩm", "COMPARE"),

                permission("CART_VIEW", "Xem giỏ hàng", "CART"),
                permission("CART_ADD", "Thêm vào giỏ hàng", "CART"),
                permission("CART_UPDATE", "Cập nhật giỏ hàng", "CART"),
                permission("CART_DELETE", "Xóa khỏi giỏ hàng", "CART"),

                permission("ORDER_CREATE", "Tạo đơn hàng", "ORDER"),
                permission("ORDER_VIEW", "Xem đơn hàng", "ORDER"),
                permission("ORDER_UPDATE", "Cập nhật đơn hàng", "ORDER"),
                permission("ORDER_DELETE", "Xóa đơn hàng", "ORDER"),

                permission("REVIEW_VIEW", "Xem bình luận", "REVIEW"),
                permission("REVIEW_CREATE", "Thêm bình luận", "REVIEW"),
                permission("REVIEW_UPDATE", "Sửa bình luận", "REVIEW"),
                permission("REVIEW_DELETE", "Xóa bình luận", "REVIEW"),
                permission("REVIEW_REPLY", "Phản hồi đánh giá", "REVIEW"),

                permission("COIN_TASK_VIEW", "Xem nhiệm vụ xu", "COIN"),
                permission("COIN_TASK_CREATE", "Thêm nhiệm vụ xu", "COIN"),
                permission("COIN_TASK_UPDATE", "Sửa nhiệm vụ xu", "COIN"),
                permission("COIN_TASK_DELETE", "Xóa nhiệm vụ xu", "COIN")
        );

        for (AccessPermission permission : permissions) {
            accessPermissionRepository.findByCode(permission.getCode())
                    .orElseGet(() -> accessPermissionRepository.save(permission));
        }

        createSystemRole("USER", "Khách hàng", List.of());

        createSystemRole(
                "ADMIN",
                "Quản trị viên",
                List.of(
                        "USER_VIEW",
                        "USER_CREATE",
                        "USER_UPDATE",
                        "USER_LOCK",
                        "USER_DELETE",
                        "CUSTOMER_VIEW",
                        "STAFF_VIEW",
                        "PHONE_PREFIX_VIEW",
                        "PHONE_PREFIX_MANAGE",

                        "NEWS_TOPIC_VIEW",
                        "NEWS_TOPIC_CREATE",
                        "NEWS_TOPIC_UPDATE",
                        "NEWS_TOPIC_DELETE",

                        "NEWS_POST_VIEW",
                        "NEWS_POST_CREATE",
                        "NEWS_POST_UPDATE",
                        "NEWS_POST_DELETE",
                        "NEWS_POST_PUBLISH",

                        "CONTACT_VIEW",
                        "CONTACT_REPLY",
                        "CONTACT_UPDATE",

                        "DASHBOARD_VIEW",
                        "ANALYTICS_VIEW",
                        "ANALYTICS_EXPORT",

                        "RECOMMENDATION_VIEW",
                        "RECOMMENDATION_MANAGE",
                        "BEHAVIOR_VIEW",
                        "ANNOUNCEMENT_VIEW",
                        "ANNOUNCEMENT_MANAGE",

                        "WALLET_VIEW",
                        "WALLET_TOPUP",
                        "WALLET_DEDUCT",
                        "WALLET_TRANSACTION_VIEW",

                        "MEMBERSHIP_VIEW",
                        "MEMBERSHIP_UPDATE",
                        "MEMBERSHIP_MANAGE",

                        "PAYMENT_VIEW",
                        "PAYMENT_USE",
                        "PAYMENT_MANAGE",
                        "PAYMENT_VERIFY",

                        "VOUCHER_VIEW",
                        "VOUCHER_CREATE",
                        "VOUCHER_UPDATE",
                        "VOUCHER_DELETE",
                        "VOUCHER_VALIDATE",
                        "VOUCHER_APPLY",

                        "PRODUCT_VIEW",
                        "PRODUCT_CREATE",
                        "PRODUCT_UPDATE",
                        "PRODUCT_DELETE",
                        "PRODUCT_MANAGE",

                        "BRAND_VIEW",
                        "BRAND_CREATE",
                        "BRAND_UPDATE",
                        "BRAND_DELETE",

                        "LIVESTREAM_VIEW",
                        "LIVESTREAM_MANAGE",

                        "PRODUCT_VIDEO_VIEW",
                        "PRODUCT_VIDEO_MANAGE",

                        "CATEGORY_VIEW",
                        "CATEGORY_CREATE",
                        "CATEGORY_UPDATE",
                        "CATEGORY_DELETE",

                        "INVENTORY_VIEW",
                        "INVENTORY_UPDATE",

                        "IMAGE_UPLOAD",
                        "IMAGE_DELETE",

                        "VISION_SEARCH",
                        "VISION_MANAGE",

                        "COMPARE_PRODUCT_USE",

                        "ORDER_VIEW",
                        "ORDER_UPDATE",

                        "REVIEW_VIEW",
                        "REVIEW_UPDATE",
                        "REVIEW_DELETE",
                        "REVIEW_REPLY",
                        "COIN_TASK_VIEW",
                        "COIN_TASK_CREATE",
                        "COIN_TASK_UPDATE",
                        "COIN_TASK_DELETE"
                )
        );

        createSystemRole(
                "SUPER_ADMIN",
                "Siêu quản trị",
                List.of(
                        "ROLE_MANAGE",
                        "ROLE_ASSIGN",

                        "USER_VIEW",
                        "USER_CREATE",
                        "USER_UPDATE",
                        "USER_DELETE",
                        "USER_LOCK",
                        "CUSTOMER_VIEW",
                        "STAFF_VIEW",

                        "PHONE_PREFIX_VIEW",
                        "PHONE_PREFIX_MANAGE",

                        "NEWS_TOPIC_VIEW",
                        "NEWS_TOPIC_CREATE",
                        "NEWS_TOPIC_UPDATE",
                        "NEWS_TOPIC_DELETE",

                        "NEWS_POST_VIEW",
                        "NEWS_POST_CREATE",
                        "NEWS_POST_UPDATE",
                        "NEWS_POST_DELETE",
                        "NEWS_POST_PUBLISH",

                        "CONTACT_VIEW",
                        "CONTACT_REPLY",
                        "CONTACT_UPDATE",

                        "DASHBOARD_VIEW",
                        "ANALYTICS_VIEW",
                        "ANALYTICS_EXPORT",

                        "RECOMMENDATION_VIEW",
                        "RECOMMENDATION_MANAGE",
                        "BEHAVIOR_VIEW",
                        "ANNOUNCEMENT_VIEW",
                        "ANNOUNCEMENT_MANAGE",

                        "WALLET_VIEW",
                        "WALLET_TOPUP",
                        "WALLET_DEDUCT",
                        "WALLET_TRANSACTION_VIEW",

                        "MEMBERSHIP_VIEW",
                        "MEMBERSHIP_UPDATE",
                        "MEMBERSHIP_MANAGE",

                        "PAYMENT_VIEW",
                        "PAYMENT_USE",
                        "PAYMENT_MANAGE",
                        "PAYMENT_VERIFY",

                        "VOUCHER_VIEW",
                        "VOUCHER_CREATE",
                        "VOUCHER_UPDATE",
                        "VOUCHER_DELETE",
                        "VOUCHER_VALIDATE",
                        "VOUCHER_APPLY",

                        "PRODUCT_VIEW",
                        "PRODUCT_CREATE",
                        "PRODUCT_UPDATE",
                        "PRODUCT_DELETE",
                        "PRODUCT_MANAGE",

                        "BRAND_VIEW",
                        "BRAND_CREATE",
                        "BRAND_UPDATE",
                        "BRAND_DELETE",

                        "LIVESTREAM_VIEW",
                        "LIVESTREAM_MANAGE",

                        "PRODUCT_VIDEO_VIEW",
                        "PRODUCT_VIDEO_MANAGE",

                        "CATEGORY_VIEW",
                        "CATEGORY_CREATE",
                        "CATEGORY_UPDATE",
                        "CATEGORY_DELETE",

                        "INVENTORY_VIEW",
                        "INVENTORY_UPDATE",

                        "IMAGE_UPLOAD",
                        "IMAGE_DELETE",

                        "VISION_SEARCH",
                        "VISION_MANAGE",

                        "COMPARE_PRODUCT_USE",

                        "CART_VIEW",
                        "CART_ADD",
                        "CART_UPDATE",
                        "CART_DELETE",

                        "ORDER_CREATE",
                        "ORDER_VIEW",
                        "ORDER_UPDATE",
                        "ORDER_DELETE",

                        "REVIEW_VIEW",
                        "REVIEW_CREATE",
                        "REVIEW_UPDATE",
                        "REVIEW_DELETE",
                        "REVIEW_REPLY",
                        "COIN_TASK_VIEW",
                        "COIN_TASK_CREATE",
                        "COIN_TASK_UPDATE",
                        "COIN_TASK_DELETE"
                )
        );
    }

    private void createSystemRole(String code, String name, List<String> permissionCodes) {
        AccessRole role = accessRoleRepository.findByCodeIgnoreCase(code)
                .orElseGet(() -> accessRoleRepository.save(
                        AccessRole.builder()
                                .code(code)
                                .name(name)
                                .description(name)
                                .systemRole(true)
                                .build()
                ));

        Set<AccessPermission> permissions = new LinkedHashSet<>();
        for (String permissionCode : permissionCodes) {
            accessPermissionRepository.findByCode(permissionCode).ifPresent(permissions::add);
        }

        role.setPermissions(permissions);
        accessRoleRepository.save(role);
    }

    private AccessPermission permission(String code, String name, String module) {
        return AccessPermission.builder()
                .code(code)
                .name(name)
                .module(module)
                .description(name)
                .build();
    }

    private void seedAdminAccount() {
        if (userRepository.existsByEmailIgnoreCase("admin@novashop.vn")) return;

        User admin = User.builder()
                .fullName("Nova Admin")
                .email("admin@novashop.vn")
                .passwordHash(passwordEncoder.encode("Admin@123"))
                .role(RoleName.SUPER_ADMIN)
                .active(true)
                .authProvider("LOCAL")
                .build();

        User saved = userRepository.save(admin);

        userAddressRepository.save(
                UserAddress.builder()
                        .user(saved)
                        .recipientName("Nova Admin")
                        .phone("0909123456")
                        .addressLine("68 Nguyễn Huệ, Quận 1, TP.HCM")
                        .isDefault(true)
                        .build()
        );
    }

    private void seedNewsContent() {
        if (newsTopicRepository.count() > 0 || newsPostRepository.count() > 0) return;

        LocalDateTime now = LocalDateTime.now();

        NewsTopic tech = newsTopicRepository.save(NewsTopic.builder()
                .name("Công nghệ")
                .slug("cong-nghe")
                .description("Tin tức công nghệ mới nhất")
                .active(true)
                .displayOrder(1)
                .createdAt(now)
                .updatedAt(now)
                .build());

        NewsTopic review = newsTopicRepository.save(NewsTopic.builder()
                .name("Đánh giá")
                .slug("danh-gia")
                .description("Các bài đánh giá thiết bị nổi bật")
                .active(true)
                .displayOrder(2)
                .createdAt(now)
                .updatedAt(now)
                .build());

        NewsTopic tips = newsTopicRepository.save(NewsTopic.builder()
                .name("Thủ thuật")
                .slug("thu-thuat")
                .description("Mẹo sử dụng thiết bị hiệu quả hơn")
                .active(true)
                .displayOrder(3)
                .createdAt(now)
                .updatedAt(now)
                .build());

        User author = userRepository.findByEmailIgnoreCase("admin@novashop.vn").orElse(null);
        if (author == null) return;

        newsPostRepository.save(NewsPost.builder()
                .title("Kỷ nguyên chip M4: Apple thiết lập tiêu chuẩn mới cho hiệu năng AI")
                .slug("ky-nguyen-chip-m4-apple-thiet-lap-tieu-chuan-moi-cho-hieu-nang-ai")
                .summary("Phân tích sức mạnh mới của chip M4 và tác động lên hệ sinh thái thiết bị hiện đại.")
                .content("<p>Apple tiếp tục tạo dấu ấn với thế hệ chip M4 mới, tối ưu mạnh cho các tác vụ AI và hiệu suất đồ họa.</p><p>Trong bài viết này, NovaShop sẽ phân tích điểm mới, hiệu năng và trải nghiệm thực tế mà M4 mang lại.</p><h3>Điểm nổi bật</h3><ul><li>Hiệu suất CPU/GPU tăng đáng kể</li><li>Tối ưu cho các ứng dụng AI</li><li>Tiết kiệm điện năng hơn</li></ul>")
                .thumbnail("https://images.unsplash.com/photo-1498050108023-c5249f4df085?q=80&w=1200")
                .status(NewsPostStatus.PUBLISHED)
                .featured(true)
                .viewCount(1200L)
                .publishedAt(now.minusDays(2))
                .createdAt(now)
                .updatedAt(now)
                .topic(tech)
                .author(author)
                .build());

        newsPostRepository.save(NewsPost.builder()
                .title("Đánh giá ROG Strix SCAR 18 (2026): quái vật gaming cho game thủ chuyên nghiệp")
                .slug("danh-gia-rog-strix-scar-18-2026")
                .summary("Mẫu laptop gaming hiệu năng cao với màn hình mini-LED và hệ tản nhiệt nâng cấp.")
                .content("<p>ROG Strix SCAR 18 hướng đến game thủ hiệu năng cao với cấu hình mạnh, màn hình lớn và tản nhiệt tốt.</p>")
                .thumbnail("https://images.unsplash.com/photo-1629429408209-1f912961dbd8?q=80&w=1200")
                .status(NewsPostStatus.PUBLISHED)
                .featured(false)
                .viewCount(980L)
                .publishedAt(now.minusDays(3))
                .createdAt(now)
                .updatedAt(now)
                .topic(review)
                .author(author)
                .build());

        newsPostRepository.save(NewsPost.builder()
                .title("Cách tối ưu pin trên iPhone trong 5 phút")
                .slug("cach-toi-uu-pin-tren-iphone-trong-5-phut")
                .summary("Một số thiết lập nhỏ nhưng giúp thời lượng pin cải thiện rõ rệt mỗi ngày.")
                .content("<p>Việc tối ưu pin trên iPhone có thể bắt đầu từ điều chỉnh độ sáng, dịch vụ nền và các tuỳ chọn hệ thống cơ bản.</p>")
                .thumbnail("https://images.unsplash.com/photo-1511707171634-5f897ff02aa9?q=80&w=1200")
                .status(NewsPostStatus.PUBLISHED)
                .featured(false)
                .viewCount(860L)
                .publishedAt(now.minusDays(1))
                .createdAt(now)
                .updatedAt(now)
                .topic(tips)
                .author(author)
                .build());

        newsPostRepository.save(NewsPost.builder()
                .title("Xu hướng setup bàn làm việc tối giản trong năm 2026")
                .slug("xu-huong-setup-ban-lam-viec-toi-gian-trong-nam-2026")
                .summary("Góc làm việc đẹp, gọn gàng giúp tăng cảm hứng và khả năng tập trung khi làm việc.")
                .content("<p>Phong cách tối giản đang trở thành xu hướng mạnh mẽ trong giới công nghệ và làm việc sáng tạo.</p>")
                .thumbnail("https://images.unsplash.com/photo-1498050108023-c5249f4df085?q=80&w=1200")
                .status(NewsPostStatus.PUBLISHED)
                .featured(false)
                .viewCount(740L)
                .publishedAt(now.minusHours(18))
                .createdAt(now)
                .updatedAt(now)
                .topic(tech)
                .author(author)
                .build());
    }

    private void syncUsersToDynamicRoles() {
        AccessRole userRole = accessRoleRepository.findByCodeIgnoreCase("USER").orElse(null);
        AccessRole adminRole = accessRoleRepository.findByCodeIgnoreCase("ADMIN").orElse(null);
        AccessRole superRole = accessRoleRepository.findByCodeIgnoreCase("SUPER_ADMIN").orElse(null);

        for (User user : userRepository.findAll()) {
            if (user.getAccessRoles() == null || user.getAccessRoles().isEmpty()) {
                if (user.getRole() == RoleName.SUPER_ADMIN && superRole != null) {
                    user.getAccessRoles().add(superRole);
                } else if (user.getRole() == RoleName.ADMIN && adminRole != null) {
                    user.getAccessRoles().add(adminRole);
                } else if (userRole != null) {
                    user.getAccessRoles().add(userRole);
                }
                userRepository.save(user);
            }
        }
    }
}
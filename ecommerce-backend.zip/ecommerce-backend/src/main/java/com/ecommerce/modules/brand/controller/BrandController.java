package com.ecommerce.modules.brand.controller;

import com.ecommerce.common.response.ApiResponse;
import com.ecommerce.modules.brand.dto.request.BrandRequest;
import com.ecommerce.modules.brand.dto.response.BrandResponse;
import com.ecommerce.modules.brand.service.BrandService;
import com.ecommerce.modules.upload.service.LocalStorageService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import com.ecommerce.modules.brand.service.BrandValidatorService;
import java.io.IOException;
import java.util.List;

@RestController
@RequestMapping("/api/v1/brands")
@RequiredArgsConstructor
public class BrandController {

    private final BrandService brandService;
    private final LocalStorageService localStorageService;
    private final BrandValidatorService brandValidator; // Inject cái validator

    @GetMapping
    public ApiResponse<List<BrandResponse>> getAll() {
        return ApiResponse.<List<BrandResponse>>builder()
                .result(brandService.getAll())
                .build();
    }

    @GetMapping("/{id}")
    public ApiResponse<BrandResponse> getById(@PathVariable Long id) {
        return ApiResponse.<BrandResponse>builder()
                .result(brandService.getById(id))
                .build();
    }

    @PreAuthorize("hasAuthority('BRAND_CREATE')")
    @PostMapping("/with-image")
    public ApiResponse<BrandResponse> createWithImage(
            @RequestPart("data") @Valid BrandRequest request,
            @RequestPart("file") MultipartFile file) throws IOException {

        // 1. PHẢI VALIDATE TRƯỚC (Để nếu trùng tên thì dừng luôn, đỡ tốn công upload)
        brandValidator.validate(request, file, null);

        String logoUrl = localStorageService.uploadFile(file, "brands");
        request.setLogo(logoUrl);


        return ApiResponse.<BrandResponse>builder()
                .result(brandService.create(request))
                .build();
    }

    // API Cập nhật thương hiệu kèm khả năng đổi ảnh mới
    @PreAuthorize("hasAuthority('BRAND_UPDATE')")
    @PutMapping("/with-image/{id}")
    public ApiResponse<BrandResponse> updateWithImage(
            @PathVariable Long id,
            @RequestPart("data") @Valid BrandRequest request, // thêm @Valid để validate request
            @RequestPart(value = "file", required = false) MultipartFile file) throws IOException {

        brandValidator.validate(request, file, id);
        
        return ApiResponse.<BrandResponse>builder()
                .result(brandService.updateWithImage(id, request, file))
                .build();
    }

    @PreAuthorize("hasAuthority('BRAND_DELETE')")
    @DeleteMapping("/{id}")
    public ApiResponse<String> delete(@PathVariable Long id) {
        brandService.delete(id);
        return ApiResponse.<String>builder()
                .result("Thương hiệu đã được xóa thành công")
                .build();
    }

}
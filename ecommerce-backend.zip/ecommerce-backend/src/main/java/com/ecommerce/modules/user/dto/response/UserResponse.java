package com.ecommerce.modules.user.dto.response;

import lombok.Builder;
import lombok.Data;

import java.time.LocalDateTime;
import java.util.List;

@Data
@Builder
public class UserResponse {
    private Long id;
    private String fullName;
    private String primaryPhone;
    private String primaryAddress;
    private String email;
    private String avatar;
    private String role;
    private List<String> roles;
    private List<String> permissions;
    private Boolean active;
    private Boolean deleted;
    private LocalDateTime deletedAt;
    private String authProvider;
    private Boolean vip;
    private String membershipCode;
    private String membershipName;
    private String membershipStatus;
    private LocalDateTime membershipStartedAt;
    private LocalDateTime membershipEndedAt;
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;
    private List<UserAddressResponse> addresses;
}

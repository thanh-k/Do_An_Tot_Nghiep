package com.ecommerce.modules.voucher.dto.request;


import lombok.Builder;
import lombok.Data;
import java.time.LocalDateTime;

@Data
@Builder

public class VoucherRequest {
    private String code;
    private String category;
    private String discountType;
    private Double discountValue;
    private Double minOrderValue;
    private Integer quantity;
    private Boolean vipOnly;
    private Boolean monthlyReset;
    private Integer monthlyQuantity;
    private LocalDateTime expiryDate;
    private Boolean active;
    private String image;

    // Giá xu để đổi voucher, chỉ dùng khi category = COIN_REWARD
    private Long coinCost;
}
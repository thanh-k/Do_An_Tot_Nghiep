package com.ecommerce.common.exception;

import lombok.Getter;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;

@Getter
public enum ErrorCode {

    PRODUCT_NOT_FOUND(1018, "Không tìm thấy sản phẩm", HttpStatus.NOT_FOUND),


    COIN_TASK_NOT_FOUND(1601, "Không tìm thấy nhiệm vụ xu", HttpStatus.NOT_FOUND),
    COIN_TASK_INVALID(1602, "Thông tin nhiệm vụ xu không hợp lệ", HttpStatus.BAD_REQUEST),
    COIN_TASK_CODE_EXISTS(1603, "Mã nhiệm vụ xu đã tồn tại", HttpStatus.BAD_REQUEST),

    UNCATEGORIZED_EXCEPTION(9999, "Lỗi hệ thống chưa xác định", HttpStatus.INTERNAL_SERVER_ERROR),
    INVALID_KEY(1001, "Mã lỗi không hợp lệ", HttpStatus.BAD_REQUEST),

    CATEGORY_EXITED(1002, "Tên danh mục này đã tồn tại!", HttpStatus.BAD_REQUEST),
    CATEGORY_NOT_FOUND(1003, "Không tìm thấy danh mục!", HttpStatus.NOT_FOUND),
    // INVALID_CATEGORY_NAME
    // Lỗi về Category Validation
    INVALID_CATEGORY_NAME(1011, "Tên danh mục không được để trống và phải từ 2-50 ký tự", HttpStatus.BAD_REQUEST),
    // (Mã 1002 nếu ní đã có thì giữ nguyên, chỉ cần thêm cái INVALID_CATEGORY_NAME
    // thôi)

    // Lỗi về Brand


    // Trong file common/exception/ErrorCode.java
    INVALID_BRAND_NAME(1019, "Tên thương hiệu không được để trống và phải từ 2-50 ký tự", HttpStatus.BAD_REQUEST),
    INVALID_FILE_FORMAT(1020, "Chỉ chấp nhận ảnh định dạng .jpg, .jpeg, .png, .webp", HttpStatus.BAD_REQUEST),
    FILE_TOO_LARGE(1021, "Dung lượng ảnh tối đa là 2MB", HttpStatus.BAD_REQUEST),

    // Lỗi về Product & Variant
    PRODUCT_EXISTED(1012, "Tên sản phẩm này đã tồn tại trên hệ thống!", HttpStatus.BAD_REQUEST),
    INVALID_PRODUCT_DATA(1013, "Vui lòng nhập đầy đủ các thông tin bắt buộc của sản phẩm", HttpStatus.BAD_REQUEST),
    SKU_EXISTED(1014, "Mã SKU của biến thể đã bị trùng lặp, vui lòng kiểm tra lại", HttpStatus.BAD_REQUEST),
    INVALID_VARIANT_NUMBER(1015, "Giá bán của biến thể phải từ 1 trở lên và Tồn kho không được là số âm",
            HttpStatus.BAD_REQUEST),
    INVALID_SPECIFICATION_FORMAT(1016, "Định dạng thông số kỹ thuật không hợp lệ", HttpStatus.BAD_REQUEST),
    INVALID_VARIANT_PRICE(1017, "Giá bán không được phép lớn hơn giá gốc", HttpStatus.BAD_REQUEST),

    USER_NOT_FOUND(1101, "Không tìm thấy người dùng", HttpStatus.NOT_FOUND),
    LOGIN_FAILED(1102, "Tài khoản hoặc mật khẩu không chính xác", HttpStatus.UNAUTHORIZED),
    EMAIL_INVALID(1103, "Email không hợp lệ", HttpStatus.BAD_REQUEST),
    PHONE_INVALID(1104, "Số điện thoại phải gồm đúng 10 chữ số", HttpStatus.BAD_REQUEST),
    PHONE_ALREADY_EXISTS(1105, "Số điện thoại đã được tài khoản khác sử dụng", HttpStatus.BAD_REQUEST),
    EMAIL_ALREADY_EXISTS(1106, "Email đã tồn tại", HttpStatus.BAD_REQUEST),
    PASSWORD_INVALID(1107, "Mật khẩu phải có ít nhất 6 ký tự, gồm 1 chữ in hoa, 1 số và 1 ký tự đặc biệt", HttpStatus.BAD_REQUEST),
    FULL_NAME_INVALID(1108, "Họ và tên chỉ được chứa chữ cái và khoảng trắng, tối thiểu 2 ký tự", HttpStatus.BAD_REQUEST),
    ROLE_INVALID(1109, "Vai trò không hợp lệ", HttpStatus.BAD_REQUEST),
    USER_DISABLED(1110, "Tài khoản đã bị khóa", HttpStatus.FORBIDDEN),
    CURRENT_PASSWORD_INCORRECT(1111, "Mật khẩu hiện tại không chính xác", HttpStatus.BAD_REQUEST),
    ADMIN_CANNOT_DELETE(1112, "Không thể xóa tài khoản quản trị viên", HttpStatus.BAD_REQUEST),
    AVATAR_REQUIRED(1113, "Vui lòng chọn ảnh đại diện", HttpStatus.BAD_REQUEST),
    PHONE_REQUIRED(1114, "Số điện thoại là bắt buộc", HttpStatus.BAD_REQUEST),
    LOGIN_USE_GOOGLE(1115, "Tài khoản này được đăng ký bằng Google. Vui lòng đăng nhập bằng Google", HttpStatus.BAD_REQUEST),
    ACCOUNT_NOT_FOUND_BY_GOOGLE(1116, "Email Google này chưa có tài khoản trong hệ thống", HttpStatus.BAD_REQUEST),
    GOOGLE_EMAIL_ALREADY_EXISTS(1117, "Email Google này đã có tài khoản", HttpStatus.BAD_REQUEST),
    GOOGLE_TEMP_TOKEN_INVALID(1118, "Phiên đăng ký Google không hợp lệ hoặc đã hết hạn", HttpStatus.BAD_REQUEST),
    ADDRESS_NOT_FOUND(1119, "Không tìm thấy địa chỉ", HttpStatus.NOT_FOUND),
    ADDRESS_REQUIRED(1120, "Địa chỉ là bắt buộc", HttpStatus.BAD_REQUEST),
    OTP_INVALID(1121, "Mã xác thực không hợp lệ", HttpStatus.BAD_REQUEST),
    OTP_EXPIRED(1122, "Mã xác thực đã hết hạn", HttpStatus.BAD_REQUEST),
    ACCOUNT_CANCELLATION_REQUEST_EXISTS(1123, "Bạn đã gửi yêu cầu hủy tài khoản và đang chờ quản trị viên xử lý", HttpStatus.BAD_REQUEST),
    ACCOUNT_CANCELLATION_REQUEST_NOT_FOUND(1124, "Không tìm thấy yêu cầu hủy tài khoản", HttpStatus.NOT_FOUND),
    ACCOUNT_CANCELLATION_REQUEST_PROCESSED(1125, "Yêu cầu hủy tài khoản đã được xử lý", HttpStatus.BAD_REQUEST),
    ACCOUNT_CANCELLATION_HAS_UNFINISHED_ORDERS(1126, "Không thể hủy tài khoản vì khách hàng còn đơn hàng chưa hoàn thành", HttpStatus.BAD_REQUEST),

    PHONE_PREFIX_NOT_FOUND(1201, "Không tìm thấy đầu số", HttpStatus.NOT_FOUND),
    PHONE_PREFIX_ALREADY_EXISTS(1202, "Đầu số đã tồn tại", HttpStatus.BAD_REQUEST),
    PHONE_PREFIX_INVALID(1203, "Đầu số phải gồm đúng 3 chữ số", HttpStatus.BAD_REQUEST),
    PHONE_PROVIDER_INVALID(1204, "Tên nhà mạng không hợp lệ", HttpStatus.BAD_REQUEST),
    PHONE_PREFIX_NOT_ALLOWED(1205, "Đầu số điện thoại chưa được cho phép", HttpStatus.BAD_REQUEST),

    VOUCHER_NOT_FOUND(1401, "Không tìm thấy voucher", HttpStatus.NOT_FOUND),
    VOUCHER_INVALID(1402, "Voucher không hợp lệ, đã hết hạn hoặc hết lượt sử dụng", HttpStatus.BAD_REQUEST),
    VOUCHER_MIN_ORDER_NOT_MET(1403, "Đơn hàng chưa đạt giá trị tối thiểu để sử dụng voucher", HttpStatus.BAD_REQUEST),
    INVALID_VOUCHER_DATA(1404, "Vui lòng nhập đầy đủ các thông tin bắt buộc của voucher", HttpStatus.BAD_REQUEST),
    VOUCHER_IMAGE_REQUIRED(1405, "Vui lòng chọn ảnh cho voucher", HttpStatus.BAD_REQUEST),

    BRAND_EXISTED(1008, "Thương hiệu đã tồn tại", HttpStatus.BAD_REQUEST),
    BRAND_NOT_FOUND(1009, "Không tìm thấy thương hiệu", HttpStatus.NOT_FOUND),

    ROLE_NOT_FOUND(1301, "Không tìm thấy vai trò", HttpStatus.NOT_FOUND),
    ROLE_ALREADY_EXISTS(1302, "Mã vai trò đã tồn tại", HttpStatus.BAD_REQUEST),
    ROLE_REQUIRED(1303, "Vui lòng chọn ít nhất một vai trò", HttpStatus.BAD_REQUEST),
    ROLE_CODE_REQUIRED(1304, "Mã vai trò là bắt buộc", HttpStatus.BAD_REQUEST),
    SYSTEM_ROLE_LOCKED(1305, "Không thể chỉnh sửa vai trò hệ thống", HttpStatus.BAD_REQUEST),

    NEWS_TOPIC_NOT_FOUND(1401, "Không tìm thấy chủ đề tin tức", HttpStatus.NOT_FOUND),
    NEWS_TOPIC_ALREADY_EXISTS(1402, "Chủ đề tin tức đã tồn tại", HttpStatus.BAD_REQUEST),
    NEWS_TOPIC_REQUIRED(1403, "Tên chủ đề tin tức là bắt buộc", HttpStatus.BAD_REQUEST),
    NEWS_TOPIC_HAS_POSTS(1404, "Không thể xóa chủ đề vì vẫn còn bài viết", HttpStatus.BAD_REQUEST),
    NEWS_POST_NOT_FOUND(1411, "Không tìm thấy bài viết", HttpStatus.NOT_FOUND),
    NEWS_POST_REQUIRED(1412, "Tiêu đề bài viết là bắt buộc", HttpStatus.BAD_REQUEST),
    NEWS_POST_CONTENT_REQUIRED(1413, "Nội dung bài viết là bắt buộc", HttpStatus.BAD_REQUEST),
    NEWS_POST_STATUS_REQUIRED(1414, "Trạng thái bài viết là bắt buộc", HttpStatus.BAD_REQUEST),
    CONTACT_NOT_FOUND(1501, "Không tìm thấy liên hệ", HttpStatus.NOT_FOUND),
    CONTACT_NAME_INVALID(1502, "Họ và tên liên hệ không hợp lệ", HttpStatus.BAD_REQUEST),
    CONTACT_PHONE_INVALID(1503, "Số điện thoại liên hệ phải gồm đúng 10 chữ số", HttpStatus.BAD_REQUEST),
    CONTACT_EMAIL_INVALID(1504, "Email liên hệ không hợp lệ", HttpStatus.BAD_REQUEST),
    CONTACT_MESSAGE_INVALID(1505, "Nội dung liên hệ phải có ít nhất 10 ký tự", HttpStatus.BAD_REQUEST),
    CONTACT_STATUS_REQUIRED(1506, "Trạng thái liên hệ là bắt buộc", HttpStatus.BAD_REQUEST),
    CONTACT_REPLY_REQUIRED(1507, "Nội dung phản hồi là bắt buộc", HttpStatus.BAD_REQUEST),
    CONTACT_MESSAGE_REQUIRED(400, "Vui lòng nhập nội dung liên hệ", HttpStatus.BAD_REQUEST),
    MEMBERSHIP_PLAN_NOT_FOUND(1601, "Không tìm thấy gói thành viên", HttpStatus.NOT_FOUND),
    MEMBERSHIP_PLAN_INVALID(1602, "Gói thành viên không hợp lệ", HttpStatus.BAD_REQUEST),
    MEMBERSHIP_PURCHASE_INVALID(1603, "Không thể đăng ký gói thành viên này", HttpStatus.BAD_REQUEST),
    MEMBERSHIP_PLAN_ALREADY_EXISTS(1604, "Mã gói thành viên đã tồn tại", HttpStatus.BAD_REQUEST),
    MEMBERSHIP_PLAN_IN_USE(1605, "Không thể xóa gói thành viên đã có người đăng ký", HttpStatus.BAD_REQUEST),
    REVIEW_NOT_FOUND(1701, "Không tìm thấy đánh giá", HttpStatus.NOT_FOUND),
    REVIEW_INVALID(1702, "Dữ liệu đánh giá không hợp lệ", HttpStatus.BAD_REQUEST),
    REVIEW_NOT_ALLOWED(1703, "Bạn chỉ có thể đánh giá sau khi đã mua và nhận sản phẩm", HttpStatus.BAD_REQUEST),
    REVIEW_ALREADY_EXISTS(1704, "Bạn đã đánh giá sản phẩm này rồi", HttpStatus.BAD_REQUEST),

    // Lỗi về AI Compare
    NOT_ENOUGH_PRODUCTS_TO_COMPARE(1801, "Vui lòng chọn ít nhất 2 sản phẩm để thực hiện so sánh", HttpStatus.BAD_REQUEST),
    AI_ANALYSIS_FAILED(1802, "Hệ thống AI đang bận hoặc không thể phân tích lúc này, vui lòng thử lại", HttpStatus.INTERNAL_SERVER_ERROR),
    ;

    private final int code;
    private final String message;
    private final HttpStatusCode statusCode;

    ErrorCode(int code, String message, HttpStatusCode statusCode) {
        this.code = code;
        this.message = message;
        this.statusCode = statusCode;
    }
}

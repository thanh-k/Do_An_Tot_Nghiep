import HomePage from "@/pages/user/HomePage";
import ProductListPage from "@/pages/user/ProductListPage";
import ProductDetailPage from "@/pages/user/ProductDetailPage";
import SearchResultPage from "@/pages/user/SearchResultPage";
import ImageSearchPage from "@/pages/user/ImageSearchPage";
import CartPage from "@/pages/user/CartPage";
import WishlistPage from "@/pages/user/WishlistPage";
import CheckoutPage from "@/pages/user/CheckoutPage";
import ProfilePage from "@/pages/user/ProfilePage";
import OrderHistoryPage from "@/pages/user/OrderHistoryPage";
import AboutPage from "@/pages/user/AboutPage";
import ContactPage from "@/pages/user/ContactPage";
import NewsPage from "@/pages/user/NewsPage";
import NewsDetailPage from "@/pages/user/NewsDetailPage";
import VoucherPage from "@/pages/user/VoucherPage";
import ComparePage from "@/pages/user/ComparePage";
import UserDashboard from "@/pages/user/UserDashboard";
import MembershipPage from "@/pages/user/MembershipPage";
import MembershipCheckoutPage from "@/pages/user/MembershipCheckoutPage";

import FAQPage from "@/pages/user/FAQPage";
import OrderDetailPage from "@/pages/user/OrderDetailPage";
import CoinRewardsPage from "@/pages/user/CoinRewardsPage";
import LivestreamPage from "@/pages/user/LivestreamPage";

export const userRoutes = [
  { index: true, component: HomePage },
  { path: "dashboard", component: UserDashboard },
  { path: "products", component: ProductListPage },
  { path: "products/:slug", component: ProductDetailPage },
  { path: "search", component: SearchResultPage },
  { path: "image-search", component: ImageSearchPage },
  { path: "cart", component: CartPage },
  { path: "wishlist", component: WishlistPage },
  { path: "checkout", component: CheckoutPage, roles: ["user", "admin"] },
  { path: "profile", component: ProfilePage, roles: ["user", "admin"] },
  { path: "orders", component: OrderHistoryPage, roles: ["user", "admin"] },
  { path: "about", component: AboutPage },
  { path: "contact", component: ContactPage },
  { path: "news", component: NewsPage },
  { path: "news/:slug", component: NewsDetailPage },
  { path: "vouchers", component: VoucherPage },
  { path: "compare", component: ComparePage },
  { path: "membership", component: MembershipPage },
  { path: "membership/checkout", component: MembershipCheckoutPage, roles: ["user", "admin"] },
  { path: "orders/:id", component: OrderDetailPage, roles: ["user", "admin"] },
  { path: "faq", component: FAQPage },
  { path: "coins", component: CoinRewardsPage, roles: ["user", "admin"] },
  { path: "livestreams", component: LivestreamPage },
  { path: "livestreams/:id", component: LivestreamPage },
];

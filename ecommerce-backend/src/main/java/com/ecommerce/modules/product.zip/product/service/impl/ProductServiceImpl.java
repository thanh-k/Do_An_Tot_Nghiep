package com.ecommerce.modules.product.service.impl;

import com.ecommerce.common.exception.AppException;
import com.ecommerce.common.exception.ErrorCode;
import com.ecommerce.entity.*;
import com.ecommerce.modules.brand.dto.response.BrandResponse;
import com.ecommerce.modules.brand.repository.BrandRepository;
import com.ecommerce.modules.category.dto.response.CategoryResponse;
import com.ecommerce.modules.category.repository.CategoryRepository;
import com.ecommerce.modules.product.dto.request.ProductRequest;
import com.ecommerce.modules.product.dto.response.*;
import com.ecommerce.modules.product.repository.*;
import com.ecommerce.modules.order.repository.OrderDetailRepository;
import com.ecommerce.modules.product.service.ProductService;
import com.ecommerce.modules.product.service.ProductValidatorService;
import com.ecommerce.modules.review.repository.ProductReviewRepository;
import com.ecommerce.modules.upload.service.CloudinaryService;
import com.ecommerce.service.VisionServiceClient;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class ProductServiceImpl implements ProductService {

        private final ProductRepository productRepository;
        private final ProductVariantRepository variantRepository;
        private final ProductImageRepository imageRepository;
        private final CategoryRepository categoryRepository;
        private final BrandRepository brandRepository;
        private final ProductValidatorService productValidator;
        private final CloudinaryService cloudinaryService;
        private final ProductReviewRepository productReviewRepository;
        private final OrderDetailRepository orderDetailRepository;
        private final VisionServiceClient visionServiceClient;

        @Override
        @Transactional(readOnly = true)
        public ProductResponse getProductBySlug(String slug) {
                Product product = productRepository.findBySlug(slug)
                                .orElseThrow(() -> new AppException(ErrorCode.PRODUCT_NOT_FOUND));
                return getProductResponse(product);
        }

        @Override
        @Transactional
        public ProductResponse createProduct(ProductRequest request) {
                productValidator.validate(request, null);

                Category category = categoryRepository.findById(request.getCategoryId())
                                .orElseThrow(() -> new AppException(ErrorCode.UNCATEGORIZED_EXCEPTION));
                Brand brand = brandRepository.findById(request.getBrandId())
                                .orElseThrow(() -> new AppException(ErrorCode.UNCATEGORIZED_EXCEPTION));

                Product product = mapRequestToEntity(request, new Product());
                product.setCategory(category);
                product.setBrand(brand);

                Product savedProduct = productRepository.save(product);
                saveVariantsAndImages(request, savedProduct);

                // Gọi Vision Service để trích xuất và lưu vector hình ảnh
                visionServiceClient.indexProduct(savedProduct.getId(), savedProduct.getThumbnail());

                return getProductResponse(savedProduct);
        }

        @Override
        @Transactional
        public ProductResponse updateProduct(Long id, ProductRequest request) {
                Product existingProduct = productRepository.findById(id)
                                .orElseThrow(() -> new AppException(ErrorCode.UNCATEGORIZED_EXCEPTION));

                productValidator.validate(request, id);

                Set<String> oldImageUrls = new HashSet<>();
                if (existingProduct.getThumbnail() != null) {
                        oldImageUrls.add(existingProduct.getThumbnail());
                }
                if (existingProduct.getImages() != null) {
                        existingProduct.getImages().forEach(img -> {
                                if (img.getImageUrl() != null) {
                                        oldImageUrls.add(img.getImageUrl());
                                }
                        });
                }
                if (existingProduct.getVariants() != null) {
                        existingProduct.getVariants().forEach(var -> {
                                if (var.getImage() != null) {
                                        oldImageUrls.add(var.getImage());
                                }
                        });
                }

                Set<String> newImageUrls = new HashSet<>();
                if (request.getThumbnail() != null) {
                        newImageUrls.add(request.getThumbnail());
                }
                if (request.getImages() != null) {
                        newImageUrls.addAll(request.getImages());
                }
                if (request.getVariants() != null) {
                        request.getVariants().forEach(var -> {
                                if (var.getImage() != null) {
                                        newImageUrls.add(var.getImage());
                                }
                        });
                }

                for (String oldUrl : oldImageUrls) {
                        if (!newImageUrls.contains(oldUrl)) {
                                String publicId = extractPublicId(oldUrl);
                                if (publicId != null) {
                                        try {
                                                cloudinaryService.deleteFile(publicId);
                                        } catch (Exception ignored) {
                                        }
                                }
                        }
                }

                mapRequestToEntity(request, existingProduct);

                Category category = categoryRepository.findById(request.getCategoryId())
                                .orElseThrow(() -> new AppException(ErrorCode.UNCATEGORIZED_EXCEPTION));
                Brand brand = brandRepository.findById(request.getBrandId())
                                .orElseThrow(() -> new AppException(ErrorCode.UNCATEGORIZED_EXCEPTION));

                existingProduct.setCategory(category);
                existingProduct.setBrand(brand);

                if (existingProduct.getImages() != null) {
                        existingProduct.getImages().clear();
                }

                productRepository.saveAndFlush(existingProduct);

                // Cập nhật biến thể thông minh và chỉ lưu lại ảnh chung của sản phẩm
                updateProductVariantsSmart(request, existingProduct);
                saveOnlyImages(request, existingProduct);

                // Gọi Vision Service để cập nhật lại vector ảnh
                visionServiceClient.indexProduct(existingProduct.getId(), existingProduct.getThumbnail());

                return getProductResponse(existingProduct);
        }

        @Override
        @Transactional
        public void deleteProduct(Long id) {
                Product product = productRepository.findById(id)
                                .orElseThrow(() -> new AppException(ErrorCode.UNCATEGORIZED_EXCEPTION));

                cleanOldResources(product);
                productRepository.delete(product);

                // Xóa vector ảnh khỏi hệ thống AI (FAISS)
                visionServiceClient.removeProduct(id);
        }

        @Override
        @Transactional(readOnly = true)
        public List<ProductResponse> getAllProducts() {
                return productRepository.findAll().stream()
                                .map(this::getProductResponse)
                                .collect(Collectors.toList());
        }

        @Override
        @Transactional(readOnly = true)
        public ProductResponse getProductById(Long id) {
                Product product = productRepository.findById(id)
                                .orElseThrow(() -> new AppException(ErrorCode.UNCATEGORIZED_EXCEPTION));
                return getProductResponse(product);
        }

        @Override
        public void syncAllProductsToVision() {
                List<Product> products = productRepository.findAll();
                int count = 0;
                for (Product product : products) {
                        if (product.getThumbnail() != null && !product.getThumbnail().trim().isEmpty()) {
                                visionServiceClient.indexProduct(product.getId(), product.getThumbnail());
                                count++;
                        }
                }
                System.out.println("✅ Đã gửi yêu cầu đồng bộ " + count + " sản phẩm sang Vision Service.");
        }

        @Override
        @Transactional(readOnly = true)
        public List<ProductResponse> getProductsByIds(List<Long> ids) {
                // 1. Lấy dữ liệu từ DB (MySQL sẽ xáo trộn thứ tự)
                List<Product> products = productRepository.findAllById(ids);
                
                // 2. Chuyển thành Map để tra cứu nhanh
                Map<Long, Product> productMap = products.stream()
                                .collect(Collectors.toMap(Product::getId, Function.identity()));
                
                // 3. Ép Java phải giữ nguyên thứ tự ID mà AI Python đã trả về
                return ids.stream()
                                .filter(productMap::containsKey)
                                .map(id -> getProductResponse(productMap.get(id)))
                                .collect(Collectors.toList());
        }

        // --- LOGIC MỚI: CẬP NHẬT BIẾN THỂ THÔNG MINH ---
        private void updateProductVariantsSmart(ProductRequest request, Product product) {
    if (request.getVariants() == null) {
        return;
    }

    List<ProductVariant> existingVariants = product.getVariants() == null
            ? new ArrayList<>()
            : new ArrayList<>(product.getVariants());

    Map<Long, ProductVariant> existingVariantsById = existingVariants.stream()
            .filter(v -> v.getId() != null)
            .collect(Collectors.toMap(ProductVariant::getId, Function.identity()));

    Map<String, ProductVariant> existingVariantsBySku = existingVariants.stream()
            .filter(v -> v.getSku() != null && !v.getSku().isBlank())
            .collect(Collectors.toMap(
                    v -> v.getSku().trim().toUpperCase(),
                    Function.identity(),
                    (a, b) -> a
            ));

    Set<Long> incomingVariantIds = new HashSet<>();
    Set<String> requestSkus = new HashSet<>();

    List<ProductVariant> variantsToSave = new ArrayList<>();
    List<ProductVariant> variantsToRemove = new ArrayList<>();
    List<ProductVariant> onlyNewVariants = new ArrayList<>();

    for (var vReq : request.getVariants()) {
        String reqSku = normalizeSku(vReq.getSku());

        if (reqSku == null || reqSku.isBlank()) {
            throw new AppException(ErrorCode.UNCATEGORIZED_EXCEPTION);
        }

        // Chặn request tự gửi 2 variant cùng SKU
        if (!requestSkus.add(reqSku)) {
            throw new AppException(ErrorCode.UNCATEGORIZED_EXCEPTION);
        }

        ProductVariant targetVariant = null;

        // Ưu tiên match theo ID
        if (vReq.getId() != null && existingVariantsById.containsKey(vReq.getId())) {
            targetVariant = existingVariantsById.get(vReq.getId());
            incomingVariantIds.add(vReq.getId());
        }
        // Nếu FE lỡ không gửi ID nhưng SKU trùng đúng variant cũ => coi là update, không insert mới
        else if (existingVariantsBySku.containsKey(reqSku)) {
            targetVariant = existingVariantsBySku.get(reqSku);
            if (targetVariant.getId() != null) {
                incomingVariantIds.add(targetVariant.getId());
            }
        }

        if (targetVariant != null) {
            boolean isUsedInOrder = orderDetailRepository.existsByProductVariant_Id(targetVariant.getId());

            boolean isAttributeChanged = !java.util.Objects.equals(targetVariant.getAttributes(), vReq.getAttributes());
            boolean isSkuChanged = !normalizeSku(targetVariant.getSku()).equals(reqSku);

            if (isUsedInOrder && (isAttributeChanged || isSkuChanged)) {
                // Giữ biến thể cũ để bảo toàn lịch sử
                targetVariant.setStock(0);
                variantsToSave.add(targetVariant);

                // Nếu SKU mới đã tồn tại ở DB và không phải chính targetVariant -> lỗi
                if (variantRepository.existsBySkuAndIdNot(reqSku, targetVariant.getId())) {
                    throw new AppException(ErrorCode.UNCATEGORIZED_EXCEPTION);
                }

                ProductVariant newVariant = ProductVariant.builder()
                        .sku(reqSku)
                        .price(vReq.getPrice())
                        .compareAtPrice(vReq.getCompareAtPrice())
                        .stock(vReq.getStock())
                        .attributes(vReq.getAttributes())
                        .image(vReq.getImage())
                        .product(product)
                        .build();

                variantsToSave.add(newVariant);
                onlyNewVariants.add(newVariant);
            } else {
                // Update trực tiếp
                // Nếu đổi SKU thì phải check trùng với variant khác
                if (!normalizeSku(targetVariant.getSku()).equals(reqSku)
                        && variantRepository.existsBySkuAndIdNot(reqSku, targetVariant.getId())) {
                    throw new AppException(ErrorCode.UNCATEGORIZED_EXCEPTION);
                }

                targetVariant.setSku(reqSku);
                targetVariant.setPrice(vReq.getPrice());
                targetVariant.setCompareAtPrice(vReq.getCompareAtPrice());
                targetVariant.setStock(vReq.getStock());
                targetVariant.setAttributes(vReq.getAttributes());
                targetVariant.setImage(vReq.getImage());
                variantsToSave.add(targetVariant);
            }
        } else {
            // Insert mới thật sự
            if (variantRepository.existsBySku(reqSku))  {
                throw new AppException(ErrorCode.UNCATEGORIZED_EXCEPTION);
            }

            ProductVariant newVariant = ProductVariant.builder()
                    .sku(reqSku)
                    .price(vReq.getPrice())
                    .compareAtPrice(vReq.getCompareAtPrice())
                    .stock(vReq.getStock())
                    .attributes(vReq.getAttributes())
                    .image(vReq.getImage())
                    .product(product)
                    .build();

            variantsToSave.add(newVariant);
            onlyNewVariants.add(newVariant);
        }
    }

    // Những variant cũ không còn trong request
    for (ProductVariant existingVariant : existingVariants) {
        if (existingVariant.getId() == null) continue;

        if (!incomingVariantIds.contains(existingVariant.getId())) {
            boolean isUsedInOrder = orderDetailRepository.existsByProductVariant_Id(existingVariant.getId());

            if (isUsedInOrder) {
                existingVariant.setStock(0);
                variantsToSave.add(existingVariant);
            } else {
                variantsToRemove.add(existingVariant);
            }
        }
    }

    // Xóa thật trong DB trước rồi mới insert/save
    if (!variantsToRemove.isEmpty()) {
        if (product.getVariants() != null) {
            product.getVariants().removeAll(variantsToRemove);
        }
        variantRepository.deleteAll(variantsToRemove);
        variantRepository.flush();
    }

    variantRepository.saveAll(variantsToSave);
    variantRepository.flush();

    if (product.getVariants() == null) {
        product.setVariants(new HashSet<>());
    }
    product.getVariants().addAll(onlyNewVariants);
}

private String normalizeSku(String sku) {
    return sku == null ? null : sku.trim().toUpperCase();
}

        // Hàm phụ trợ để lưu ảnh khi Update (tách ra từ saveVariantsAndImages cũ)
        private void saveOnlyImages(ProductRequest request, Product product) {
                if (request.getImages() != null) {
                        List<ProductImage> images = request.getImages().stream()
                                        .map(url -> ProductImage.builder().imageUrl(url).product(product).build())
                                        .collect(Collectors.toList());
                        images = imageRepository.saveAll(images);
                        if (product.getImages() == null) {
                                product.setImages(new HashSet<>(images));
                        } else {
                                product.getImages().addAll(images);
                        }
                }
        }

        private void saveVariantsAndImages(ProductRequest request, Product product) {
                if (request.getVariants() != null) {
                        List<ProductVariant> variants = request.getVariants().stream()
                                        .map(vReq -> ProductVariant.builder()
                                                        .sku(vReq.getSku())
                                                        .price(vReq.getPrice())
                                                        .compareAtPrice(vReq.getCompareAtPrice())
                                                        .stock(vReq.getStock())
                                                        .attributes(vReq.getAttributes())
                                                        .image(vReq.getImage())
                                                        .product(product)
                                                        .build())
                                        .collect(Collectors.toList());
                        variants = variantRepository.saveAll(variants);

                        if (product.getVariants() == null) {
                                product.setVariants(new HashSet<>(variants));
                        } else {
                                product.getVariants().addAll(variants);
                        }
                } else {
                        if (product.getVariants() != null) {
                                product.getVariants().clear();
                        }
                }

                if (request.getImages() != null) {
                        List<ProductImage> images = request.getImages().stream()
                                        .map(url -> ProductImage.builder()
                                                        .imageUrl(url)
                                                        .product(product)
                                                        .build())
                                        .collect(Collectors.toList());
                        images = imageRepository.saveAll(images);

                        if (product.getImages() == null) {
                                product.setImages(new HashSet<>(images));
                        } else {
                                product.getImages().addAll(images);
                        }
                } else {
                        if (product.getImages() != null) {
                                product.getImages().clear();
                        }
                }
        }

        private String extractPublicId(String url) {
                if (url == null || !url.contains("cloudinary.com") || !url.contains("upload/")) {
                        return null;
                }
                try {
                        String[] parts = url.split("upload/");
                        if (parts.length < 2) {
                                return null;
                        }
                        String afterUpload = parts[1];

                        if (afterUpload.matches("^v\\d+/.*")) {
                                afterUpload = afterUpload.substring(afterUpload.indexOf("/") + 1);
                        }

                        return afterUpload;
                } catch (Exception e) {
                        System.err.println("Lỗi trích xuất Public ID từ URL: " + url);
                        return null;
                }
        }

        private void cleanOldResources(Product product) {
                Set<String> publicIdsToDelete = new HashSet<>();

                if (product.getThumbnail() != null) {
                        String id = extractPublicId(product.getThumbnail());
                        if (id != null) {
                                publicIdsToDelete.add(id);
                        }
                }
                if (product.getImages() != null) {
                        for (ProductImage img : product.getImages()) {
                                String id = extractPublicId(img.getImageUrl());
                                if (id != null) {
                                        publicIdsToDelete.add(id);
                                }
                        }
                }
                if (product.getVariants() != null) {
                        for (ProductVariant var : product.getVariants()) {
                                String id = extractPublicId(var.getImage());
                                if (id != null) {
                                        publicIdsToDelete.add(id);
                                }
                        }
                }

                for (String publicId : publicIdsToDelete) {
                        try {
                                cloudinaryService.deleteFile(publicId);
                        } catch (Exception e) {
                                System.err.println("Lỗi xóa ảnh Cloudinary ID " + publicId + ": " + e.getMessage());
                        }
                }
        }

        private Product mapRequestToEntity(ProductRequest request, Product product) {
                product.setName(request.getName());
                product.setSlug(request.getSlug());
                product.setShortDescription(request.getShortDescription());
                product.setDescription(request.getDescription());
                product.setSpecifications(request.getSpecifications());
                product.setThumbnail(request.getThumbnail());
                product.setIsFeatured(request.getIsFeatured());
                product.setIsNew(request.getIsNew());
                product.setIsSale(request.getIsSale());
                return product;
        }

        private ProductResponse getProductResponse(Product product) {
                if (product == null) {
                        return null;
                }

                try {
                        Category category = product.getCategory();
                        Brand brand = product.getBrand();
                        List<ProductVariant> variants = new ArrayList<>(
                                        product.getVariants() != null ? product.getVariants() : new HashSet<>());
                        List<ProductImage> images = new ArrayList<>(
                                        product.getImages() != null ? product.getImages() : new HashSet<>());

                        List<ProductReview> reviews = productReviewRepository
                                        .findByProductIdAndIsVisibleTrueOrderByCreatedAtDesc(product.getId());
                        double averageRating = reviews.isEmpty()
                                        ? 0.0
                                        : reviews.stream().mapToInt(ProductReview::getRating).average().orElse(0.0);
                        long reviewCount = reviews.size();

                        return ProductResponse.builder()
                                        .id(product.getId())
                                        .name(product.getName())
                                        .slug(product.getSlug())
                                        .thumbnail(product.getThumbnail())
                                        .shortDescription(product.getShortDescription())
                                        .description(product.getDescription())
                                        .specifications(product.getSpecifications())
                                        .isFeatured(product.getIsFeatured())
                                        .isNew(product.getIsNew())
                                        .isSale(product.getIsSale())
                                        .rating(Math.round(averageRating * 10.0) / 10.0)
                                        .reviewCount(reviewCount)
                                        .category(category != null
                                                        ? CategoryResponse.builder()
                                                                        .id(category.getId())
                                                                        .name(category.getName())
                                                                        .build()
                                                        : null)
                                        .brand(brand != null
                                                        ? BrandResponse.builder()
                                                                        .id(brand.getId())
                                                                        .name(brand.getName())
                                                                        .build()
                                                        : null)
                                        .variants(variants.stream()
                                                        .map(v -> VariantResponse.builder()
                                                                        .id(v.getId())
                                                                        .sku(v.getSku())
                                                                        .price(v.getPrice())
                                                                        .compareAtPrice(v.getCompareAtPrice())
                                                                        .stock(v.getStock())
                                                                        .attributes(v.getAttributes())
                                                                        .image(v.getImage())
                                                                        .hasOrders(orderDetailRepository.existsByProductVariant_Id(v.getId()))
                                                                        .build())
                                                        .collect(Collectors.toList()))
                                        .images(images.stream()
                                                        .map(ProductImage::getImageUrl)
                                                        .collect(Collectors.toList()))
                                        .build();

                } catch (Exception e) {
                        System.err.println("LỖI XẢY RA TẠI GETPRODUCTRESPONSE: " + e.getMessage());
                        e.printStackTrace();
                        throw new AppException(ErrorCode.UNCATEGORIZED_EXCEPTION);
                }
        }
}